package irc.cena;

public class Main {
	public static void main(String[] args) throws Exception {
		CyberCena bot = null;
		try {
			// Start the bot.
			bot = new CyberCena();

			// enable debug output.
			bot.setVerbose(true);

			// connect to server.
			bot.connect("99.8.10.18", 80);
			
			// join #dendi.
			bot.joinChannel("#dendi");
        	bot.joinChannel("#secretdendi");
        	bot.joinChannel("#d&d");
        
		} catch (Exception e) {
			e.printStackTrace();
			if (bot != null) {
				bot.disconnect();
				bot.dispose();
			}
		}
	}
}
package irc.cena.util;

import java.util.List;

public class GoogleResults {
	public ResponseData responseData;
	
	public static class ResponseData {
		public List<Result> results;
	}
	
	public static class Result {
		public String url;
		public String title;
		public String titleNoFormatting;
	}
}

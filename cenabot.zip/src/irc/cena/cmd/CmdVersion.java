/**
 * 
 */
package irc.cena.cmd;

/**
 * @author Andrew Ladd (Coyote_Bongwater)
 *
 * 3:25:02 PM
 */
public class CmdVersion extends Cmd {

	public CmdVersion() {
		super("version", "!version");
	}

	/* (non-Javadoc)
	 * @see irc.cena.cmd.Cmd#handle(java.lang.String, java.lang.String, java.lang.String, java.lang.String, java.lang.String[])
	 */
	@Override
	public void handle(String channel, String sender, String login, String hostname, String[] args) {
		// TODO Auto-generated method stub
		john.sendMsg("::CYBERCENA:: Alpha Build 0.3.0");
	}

	/* (non-Javadoc)
	 * @see irc.cena.cmd.Cmd#getDescription()
	 */
	@Override
	public String getDescription() {
		// TODO Auto-generated method stub
		return "Gets the current version of CyberCena.";
	}

	/* (non-Javadoc)
	 * @see irc.cena.cmd.Cmd#getUsage()
	 */
	@Override
	public String getUsage() {
		// TODO Auto-generated method stub
		return "!version";
	}
}

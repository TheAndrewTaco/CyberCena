package irc.cena.cmd;

/**
 * @author William
 * @since Aug 6, 2015
 */
public class CmdHelp extends Cmd {

	public CmdHelp() {
		super("help", "?", "h");
	}
	
	@Override
	public void handle(String channel, String sender, String login, String hostname,
			String[] args) {
		if (args.length == 0) {
			for (Cmd c : john.getCommands()) {
				john.sendMsg('!' + c.getName());
			}
		} else {
			for (Cmd c : john.getCommands()) {
				if (c.nameMatches(args[0])) {
					john.sendMsg(c.getName());
					john.sendMsg("Usage: " + c.getUsage());
					john.sendMsg("Description: " + c.getDescription());
					break;
				}
			}
		}
	}

	@Override
	public String getDescription() {
		return "Replies with a list of commands or help info for a specific command.";
	}

	@Override
	public String getUsage() {
		return "!help | !help [command]";
	}
}

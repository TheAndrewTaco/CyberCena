package irc.cena.cmd;
import irc.cena.CyberCena;

/**
 * @author Andrew Ladd (Coyote_Bongwater)
 *
 * 1:26:53 PM
 */
public class CmdMotd extends Cmd {
	
	public CmdMotd() {
		super("motd", "!motd");
	}

	@Override
	public void handle(String channel, String sender, String login, String hostname, String[] args) {
		john.sendMsg("Today's message is: " + CyberCena.motd);
	}

	@Override
	public String getDescription() {
		return "Displays the current message of the day given to the bot.";
	}

	@Override
	public String getUsage() {
		return "!motd";
	}

	
}

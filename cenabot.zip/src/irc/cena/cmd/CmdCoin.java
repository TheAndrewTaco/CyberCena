package irc.cena.cmd;

import java.util.Arrays;
import java.util.Random;

/**
 * @author William
 * @since Aug 6, 2015
 */
public class CmdCoin extends Cmd {
	private Random rng;

	public CmdCoin() {
		super("coin", "flip");
		rng = new Random();
	}

	@Override
	public void handle(String channel, String sender, String login, String hostname, String[] args) {
		int times = 1;
		System.out.println(Arrays.toString(args));
		if (args.length > 0) {
			try {
				times = Integer.parseInt(args[0]);
			} catch (NumberFormatException e) {
				john.sendMsg("That's not a number, asshole!");
			}
		}
		
		if (times == 1) {
			john.sendMsg("Flipping a coin... " + (rng.nextBoolean() ? "Heads!" : "Tails!"));
		} else {
			if (times >= 10) {
				john.sendMsg("That's too many flips for me... tell you what, I'll do nine coin flips.");
				times = 9;
			}
			
			for (int i = 1; i <= times; i++) {
				john.sendMsg("Flipping a coin... (" + i + ") " + (rng.nextBoolean() ? "Heads!" : "Tails!"));
			}
		}
	}

	@Override
	public String getDescription() {
		return "Flips a coin.";
	}

	@Override
	public String getUsage() {
		return "!coin | !coin [times]";
	}
}

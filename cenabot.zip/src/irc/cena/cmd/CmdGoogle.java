package irc.cena.cmd;

import java.io.IOException;
import java.io.InputStreamReader;
import java.io.Reader;
import java.net.URL;
import java.net.URLEncoder;
import java.util.List;

import com.google.gson.Gson;

import irc.cena.util.GoogleResults;
import irc.cena.util.GoogleResults.Result;

public class CmdGoogle extends Cmd {
	public CmdGoogle() {
		super("google", "okgoogle", "ok");
	}

	@Override
	public void handle(String channel, String sender, String login, String hostname, String[] args) {
		if (args.length > 0) {
			String query = args[0];
			String requestURL = "http://ajax.googleapis.com/ajax/services/search/web?v=1.0&q=";
			String charset = "UTF-8";
			try {
				int numresults = args.length > 1 ? Integer.parseInt(args[1]) : 5;
				URL url = new URL(requestURL + URLEncoder.encode(query, charset));
				Reader reader = new InputStreamReader(url.openStream(), charset);
				GoogleResults results = new Gson().fromJson(reader, GoogleResults.class);
				List<Result> x = results.responseData.results;
				int res = Math.min(x.size(), numresults);
				if (numresults > 4) {
					res = Math.min(res, 4);
					john.sendMsg("Woah there asshole, that's way too many results! Capping at " + res + "!");
				}
				john.sendMsg("Giving " + res + " results...");
				for (int i = 0; i < res; i++) {
					Result r = x.get(i);
					john.sendMsg((r.titleNoFormatting != null ? r.titleNoFormatting : r.title) + " - " + r.url);
				}

			} catch (IOException e) {
				john.sendMsg("Error in request.");
			} catch (NumberFormatException e) {
				john.sendMsg("Invalid number, bitch!");
			}
		} else {
			john.sendMsg("Insufficient arguments, bitch!");
		}
	}

	@Override
	public String getDescription() {
		return "Performs a Google search.";
	}

	@Override
	public String getUsage() {
		return "!google [query] | !google [query] [# of results]";
	}

}

package irc.cena.cmd;

import org.jibble.pircbot.User;

/**
 * Cleaner way to make the bot leave.
 * @author William
 * @since Aug 6, 2015
 */
public class CmdLeave extends Cmd {
	
	public CmdLeave() {
		super("leave", "forfeit", "suicide");
	}
	
	@Override
	public void handle(String channel, String sender, String login, String hostname, String[] args) {
		User[] users = john.getUsers(channel);
		for (User user : users) {
			if (user.getNick().equals(sender)) {
				if (user.isOp()) {
					john.sendMsg("I'm down for the count!");
					john.disconnect();
					john.dispose();
				}
				break;
			}
		}
	}

	@Override
	public String getDescription() {
		return "Makes the bot leave. (OP only)";
	}

	@Override
	public String getUsage() {
		return "!leave";
	}

}

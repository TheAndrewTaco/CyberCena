package irc.cena.cmd;

import java.util.List;

import com.github.jreddit.entity.Submission;
import com.github.jreddit.exception.RedditError;
import com.github.jreddit.exception.RetrievalFailedException;
import com.github.jreddit.retrieval.Submissions;
import com.github.jreddit.retrieval.params.SubmissionSort;
import com.github.jreddit.utils.restclient.PoliteHttpRestClient;
import com.github.jreddit.utils.restclient.RestClient;

public class CmdCheckReddit extends Cmd {

	public CmdCheckReddit() {
		super("reddit", "r");
	}

	@Override
	public void handle(String channel, String sender, String login, String hostname, String[] args) {
		try {
			String subreddit = args.length > 0 ? args[0] : "gooftroop420";
			int numposts = args.length > 1 ? Integer.parseInt(args[1]) : 5;
			if (numposts > 10) {
				john.sendMsg("Woah there asshole, that's way too many posts! Capping at 10!");
				numposts = 10;
			}
			RestClient client = new PoliteHttpRestClient();
			client.setUserAgent("jreddit");
			Submissions submissions = new Submissions(client);
			List<Submission> posts = submissions.ofSubreddit(subreddit, SubmissionSort.HOT, -1, numposts, null, null,
					true);
			john.sendMsg("Top " + numposts + " 'hot' posts of r/" + subreddit + ":");
			for (Submission sub : posts) {
				String content = sub.getTitle() + " by " + sub.getAuthor();
				john.sendMsg(content);
			}
		} catch (RetrievalFailedException | RedditError e) {
			e.printStackTrace();
			john.sendMsg("Error! Check console for error message.");
		} catch (NumberFormatException e) {
			john.sendMsg("That's not a number, bitch!");
		} catch (ArrayIndexOutOfBoundsException e) {
			john.sendMsg("Insufficient arguments, bitch!");
		}
	}

	@Override
	public String getDescription() {
		return "Checks reddit.";
	}

	@Override
	public String getUsage() {
		return "!reddit [subreddit] [posts]";
	}

}

package irc.cena.cmd;

import java.util.Random;

public class CmdSpeak extends Cmd {
  
  	public CmdSpeak() {
     super("speak", "meme", "memes");
   }

  //memes
  private static final String[] memeList = { "THIRTY THOUSAND DOLLARS", "The Meme King", "The Card Czar", 
"AND HIS NAME IS", "JOOOOOOOOOHN CENA!", "Danil Ishutin", "dendi", };	

  //i got lazy
  public void handle (String channel, String sender, String args[]) {
    int memes = 2;
		if (args.length > 0) {
			try {
				memes = Integer.parseInt(args[0]);
			} catch (NumberFormatException e) {
				john.sendMsg("That's not a number, asshole!");
			}
		}
  }
    @Override
    public String getDescription() {
        // TODO Auto-generated method stub
        return "Generates automated meme. We're all cogs in the meme machine.";
    }

    @Override
    public String getUsage() {
        // TODO Auto-generated method stub
        return "!meme <meme size>";
    }

    @Override
    public void handle(String arg0, String arg1, String arg2, String arg3,
            String[] arg4) {
        // TODO Auto-generated method stub
        
    }
}

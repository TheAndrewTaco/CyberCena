package irc.cena.cmd;

import java.util.Random;

/**
 * @author William
 * @since Aug 6, 2015
 */
public class CmdDice extends Cmd {
	private Random rng;

	public CmdDice() {
		super("dice", "roll", "die"); // lol @ "die"
		rng = new Random();
	}

	@Override
	public void handle(String channel, String sender, String login, String hostname, String[] args) {
		int sides = 6;
		int times = 1;
		if (args.length > 0) {
			try {
				sides = Integer.parseInt(args[0]);
			} catch (NumberFormatException e) {
				john.sendMsg("That's not a number, asshole!");
			}
		}
		
		if (args.length > 1) {
			try {
				times = Integer.parseInt(args[1]);
			} catch (NumberFormatException e) {
				john.sendMsg("That's not a number, asshole!");
			}
		}
		
		john.sendMsg("Rolling a d" + sides + "!");
		if (times == 1) {
			john.sendMsg("Rolled a " + (rng.nextInt(sides) + 1)); // 1 through [sides]
		} else {
			if (times >= 10) {
				john.sendMsg("That's too many rolls for me... tell you what, I'll do nine rolls.");
				times = 9;
			}
			for (int i = 1; i <= times; i++) {
				john.sendMsg("Roll #" + i + ": Rolled a " + (rng.nextInt(sides) + 1));
			}
		}
	}

	@Override
	public String getDescription() {
		return "Rolls a die.";
	}

	@Override
	public String getUsage() {
		return "!dice | !dice [sides] | !dice [sides] [times]";
	}
}

package irc.cena.cmd;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class CmdAFK extends Cmd {
	private Map<String, String> afkReasons;

	public CmdAFK() {
		super("afk", "away", "brb", "bbl", "back");
		afkReasons = new HashMap<>();
	}

	@Override
	public void handle(String channel, String sender, String login, String hostname, String[] args) {
		if (isAFK(sender)) {
			removeAFK(sender);
		} else {
			addAFK(sender, args.length > 0 ? args[0].trim() : "");
		}
		
		if (!afkReasons.isEmpty()) {
			john.sendMsg(": " + "List of all AFK users:");
			List<String> afkSort = new ArrayList<>(afkReasons.keySet());
			Collections.sort(afkSort); // alphabetize users
			StringBuilder sb = new StringBuilder();
			for (String user : afkSort) {
				sb.append(", ").append(user);
			}
			john.sendMsg(": " + sb.substring(2));
		}
	}
	
	private void addAFK(String user, String reason) {
		afkReasons.put(user, reason);
		if (reason.isEmpty()) {
			john.sendMsg(": " + user + " has left the ring.");
		} else {
			john.sendMsg(": " + user + " has left the ring because: \"" + reason + "\"");
		}
	}
	
	private boolean isAFK(String user) {
		return afkReasons.get(user) != null;
	}
	
	private void removeAFK(String user) {
		john.sendMsg(": " + user + " has returned to the ring!");
		afkReasons.remove(user);
	}
	
	@Override
	public void onMessage(String channel, String sender, String login, String hostname, String message) {
		super .onMessage(channel, sender, login, hostname, message);
		if (isAFK(sender)) {
			removeAFK(sender);
		}
	}

	@Override
	public void onPrivateMessage(String sender, String login, String hostname, String message) {
		super.onPrivateMessage(sender, login, hostname, message);
		if (isAFK(sender)) {
			removeAFK(sender);
		}
	}

	@Override
	public String getDescription() {
		return "Sets yourself as being AFK.";
	}

	@Override
	public String getUsage() {
		return "!afk [optional reason]";
	}
}

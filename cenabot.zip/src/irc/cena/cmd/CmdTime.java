package irc.cena.cmd;

/**
 * @author William
 * @since Aug 6, 2015
 */
public class CmdTime extends Cmd {
	public CmdTime() {
		super("time", "gettime", "t");
	}

	@Override
	public void handle(String channel, String sender, String login, 
			String hostname, String[] args) {
		String time = new java.util.Date().toString();
		john.sendMsg(": You can't see me, the time is now " + time);
	}

	@Override
	public String getDescription() {
		return "Tells the current time.";
	}

	@Override
	public String getUsage() {
		return "!time";
	}
}

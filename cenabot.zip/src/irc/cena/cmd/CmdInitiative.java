/**
 * Initiative array list for encounters. could probably be improved/upgraded.
 */

package irc.cena.cmd;

import java.util.ArrayList;
import java.util.Collections;

public class CmdInitiative extends Cmd {
  private ArrayList<Entry> inits = new ArrayList<>();
  
  public CmdInitiative() {
    super("init");
  }
  
  public void handle(String channel, String sender, String[] args) {
   
   
    if (args.length < 1) {
      // no number, use to retrieve list
      john.sendMsg("The turn order is:");
      for(Entry e:inits) {
        sendMessage(channel, "Turn: " + e);
      }
      return;
    }
    try {
    	inits.add(new Entry(sender, Integer.parseInt(args[0])));
    } catch (NumberFormatException e) {
      // clear init list
      if("clear".equals(args[0])){
        inits.clear();
      }
      return;
    }
    Collections.sort(inits);
  }

/**
 * @param channel
 * @param string
 */
private void sendMessage(String channel, String string) {
    // TODO Auto-generated method stub
    
}

@Override
public String getDescription() {
    // TODO Auto-generated method stub
    return "nerd tool";
}

@Override
public String getUsage() {
    // TODO Auto-generated method stub
    return "!init <number>";
}

@Override
public void handle(String arg0, String arg1, String arg2, String arg3,
        String[] arg4) {
    // TODO Auto-generated method stub
    
}
  
  private static class Entry implements Comparable<Entry> {
    int num;
    
    Entry(String s, int n) {
      num = n;
    }
    
    public int compareTo(Entry other) {
      return Integer.compare(num, other.num);
    }
  }
}

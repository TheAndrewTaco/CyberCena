package irc.cena.cmd;

/**
 * @author Andrew Ladd (Coyote_Bongwater) (birry pls)
 *
 * 4:04:14 PM
 */
public class CmdSetMotd {

}

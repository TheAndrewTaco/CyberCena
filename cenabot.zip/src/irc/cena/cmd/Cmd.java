package irc.cena.cmd;

import irc.cena.CyberCena;

/**
 * @author William
 * @since Aug 6, 2015
 */
public abstract class Cmd {
	public static CyberCena john;
	private String[] cmdNames;
	public Cmd(String name, String...aliases) {
		cmdNames = new String[aliases.length + 1];
		cmdNames[0] = name;
		if (aliases.length > 0) {
			System.arraycopy(aliases, 0, cmdNames, 1, aliases.length);
		}
	}
	
	public final String getName() {
		return cmdNames[0];
	}
	
	public abstract void handle(String channel, String sender, String login, 
			String hostname, String[] args);
	
	public void onMessage(String channel, String sender, String login, String hostname, String message) { }
	public void onPrivateMessage(String sender, String login, String hostname, String message) { }
	
	public abstract String getDescription();
	public abstract String getUsage();
	
	public final boolean nameMatches(String name) {
		for (String s : cmdNames) {
			if (s.equals(name)) {
				return true;
			}
		}
		return false;
	}
}

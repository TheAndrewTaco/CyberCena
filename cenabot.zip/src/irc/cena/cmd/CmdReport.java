/**
 * this is dumb but neat idk. report feature for users.
 */

package irc.cena.cmd;

import java.util.ArrayList;


public class CmdReport extends Cmd {
  
    private ArrayList<Entry> reports = new ArrayList<>();
  public CmdReport() {
    super("report");
  }


public void handle(String channel, String sender, String[] args) {
  String user = args[0];
  String reason = args[1];
  john.sendMsg("Wrestler " + user + " was reported for " + reason + ".");
  reports.add(new Entry(user, reason));
  if ("list".equals(args[0])) {
    john.sendMsg(reports.toString());
  }
}


@Override
public String getDescription() {
    // TODO Auto-generated method stub
    return "Report people for fuckery";
}


@Override
public String getUsage() {
    // TODO Auto-generated method stub
    return "!report <user> reason";
}


@Override
public void handle(String arg0, String arg1, String arg2, String arg3,
        String[] arg4) {
    // TODO Auto-generated method stub
    
}
  
  private static class Entry {
    String user, reason;
    
    Entry(String u, String r) {
      user = u;
      reason = r;
    }
    
}
  
}
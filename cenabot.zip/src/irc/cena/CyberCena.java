/**
 *  /$$$$$  /$$$$$$  /$$   /$$ /$    /$$        /$$$$$$ /$$$$$$$$  /$$   /$$  /$$$$$$ 
   |__  $$ /$$__  $$| $$  | $$| $$$ | $$       /$$__  $$| $$_____/| $$$ | $$ /$$__  $$
      | $$| $$  \ $$| $$  | $$| $$$$| $$      | $$  \__/| $$      | $$$$| $$| $$  \ $$
      | $$| $$  | $$| $$$$$$$$| $$ $$ $$      | $$      | $$$$$   | $$ $$ $$| $$$$$$$$
 /$$  | $$| $$  | $$| $$__  $$| $$  $$$$      | $$      | $$__/   | $$  $$$$| $$__  $$
| $$  | $$| $$  | $$| $$  | $$| $$\  $$$      | $$    $$| $$      | $$\  $$$| $$  | $$
|  $$$$$$/|  $$$$$$/| $$  | $$| $$ \  $$      |  $$$$$$/| $$$$$$$$| $$ \  $$| $$  | $$
 \______/  \______/ |__/  |__/|__/  \__/       \______/ |________/|__/  \__/|__/  |__/
                                                                                      
                                                                                      
 */

package irc.cena;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;
import java.util.StringTokenizer;

import org.jibble.pircbot.PircBot;

import irc.cena.cmd.Cmd;
import irc.cena.cmd.CmdAFK;
import irc.cena.cmd.CmdCheckReddit;
import irc.cena.cmd.CmdCoin;
import irc.cena.cmd.CmdDice;
import irc.cena.cmd.CmdGoogle;
import irc.cena.cmd.CmdHelp;
import irc.cena.cmd.CmdLeave;
import irc.cena.cmd.CmdMotd;
import irc.cena.cmd.CmdTime;
import irc.cena.cmd.CmdVersion;
import irc.cena.cmd.CmdInitiative;
import irc.cena.cmd.CmdReport;
import irc.cena.cmd.CmdSpeak;
public class CyberCena extends PircBot {

	//default motds will cycle everytime the bot starts
	private static final String[] defaultMOTDs = { "Is 'Champ' here? Champ?",
			"A former member of the United States Marine Core needs your support.", "AND HIS NAME IS JOHN CENA",
			"JOHN CENA, THE UNDERTAKER, RKO, AND TRIPLE H IN A SPIT-SWAPPING MAKEOUT MATCH!",
			"THAT QUESTION WILL BE ANSWERED THIS SUNDAY NIGHT!", "LIFE IS A DEATH SENTENCE", 
			":::PREMIUM RUSH::: OFFICIAL CHAT ROOM", "EXPLOSIONS! FIREBALLS! POPCORN!", "Look! It's the Meme King!",
			"I'm the Card Czar!" };

	public static Random rng = new Random();

	public static String motd = defaultMOTDs[rng.nextInt(defaultMOTDs.length)];
	
	private String channelName;
	
	private List<Cmd> commands;

	public CyberCena() {
		this.setName("CyberCena");
		Cmd.john = this;
		
		commands = new ArrayList<>();
		commands.add(new CmdTime());
		commands.add(new CmdMotd());
		commands.add(new CmdVersion());
		commands.add(new CmdHelp());
		commands.add(new CmdDice());
		commands.add(new CmdCoin());
		commands.add(new CmdLeave());
		commands.add(new CmdCheckReddit());
		commands.add(new CmdGoogle());
		commands.add(new CmdAFK());
     	commands.add(new CmdInitiative());
     	commands.add(new CmdReport());
     	commands.add(new CmdSpeak());
	}
	
	public List<Cmd> getCommands() {
		return commands;
	}

	//chat triggers
	protected void onMessage(String channel, String sender, String login, String hostname, String message) {
		channelName = channel;
		
		if (sender.equals(getNick())) {
			return;
		}
		
		if (!message.isEmpty() && message.charAt(0) == '!') {
			String cmdname = message.substring(1).split(" ")[0];
			Cmd selected = null;
			for (Cmd command : commands) {
				if (command.nameMatches(cmdname)) {
					selected = command;
					break;
				}
			}
			if (selected != null) {
				String[] temp = translateCommandline(message);
				String[] args = new String[temp.length - 1];
				System.arraycopy(temp, 1, args, 0, args.length);
				selected.handle(channel, sender, login, hostname, args);
			} else {
				sendMsg("Unknown command! Type !help for a list of commands.");
			}
		} else {
			// send message to handler methods
			for (Cmd cmd : commands) {
				cmd.onMessage(channel, sender, login, hostname, message);
			}
		}
		
		{
			String[] words = message.toLowerCase().replace("'", "").split("\\W+");
			if (checkWords(words, "cena")) {
				sendMsg(sender + ", I heard that.");
			}
			if (checkWords(words, "memory wipe")) {
				sendMsg("Wipe? What? What does that mean?");
			}
		}
	}
	
	//Greets users and itself on join
	protected void onJoin(String channel, String sender, String login, String hostname) {
		sendMessage(channel, ": Greetings, " + sender + ", and welcome to the WWE CyberSlam. Today's MOTD is: " + motd);
		channelName = channel;
		//Special message for one mobert manz
		if(sender == "mobert"){
			sendMsg("Who's hacking? MOBERT MANZ!");
		}
	}

	
	//Responds to private messages
	protected void onPrivateMessage(String sender, String login, String hostname, String message) {
		String[] words = message.toLowerCase().replace("'", "").split("\\W+");
		
		if (checkWords(words, "hi") || checkWords(words, "hello") || checkWords(words, "hey")) {
			sendMsg(sender, "Greetings, meatbag.");
		} else if (checkWords(words, "whats up")) {
			sendMsg(sender, "THE SKY, LELELELELELELELELE");
		} else if (checkWords(words, "how are you")) {
			sendMsg(sender, "Fuckin' A man, Fuckin' A.");
		} else if (checkWords(words, "ready for what")) {
			sendMsg(sender, "ARE YOU READY FOR THIS SUNDAY NIGHT IN THE WWE CYBERSLAM?! AVAILABLE NOW FOR THE LOW, LOW PRICE OF ONLY $59.99!");
		} else if (checkWords(words, "urbanski")) {
			sendMsg(sender, "He can't suspend me if I'm in The Cloud.");
		}
		
		// send message to handler methods
		for (Cmd cmd : commands) {
			cmd.onPrivateMessage(sender, login, hostname, message);
		}
	}
	
	private static boolean checkWords(String[] words, String content) {
		return checkWords(words, content.split("\\W+"));
	}
	
	private static boolean checkWords(String[] words, String[] content) {
		if (content.length <= 0) {
			return true;
		}
		outer: for (int i = 0; i < words.length; i++) {
			String word = words[i];
			if (word.equals(content[0])) {
				for (int j = i + 1, k = 1; k < content.length; j++, k++) {
					if (j >= words.length) {
						return false;
					}
					word = words[j];
					String cword = content[k];
					if (!word.equals(cword)) {
						continue outer;
					}
				}
				return true;
			}
		}
		return false;
	}
	
	//Shortened method for sending chat messages
	public void sendMsg(String msg) {
		sendMessage(channelName, msg);
	}

	public void sendMsg(String user, String msg) {
		sendMessage(user, msg);
	}
	
	/**
	 * stolen from Apache Ant's org.apache.tools.ant.types.CommandLine.translateCommandLine(String)
	 */
	public static String[] translateCommandline(String toProcess) {
		if (toProcess == null || toProcess.length() == 0) {
			return new String[0];
		}

		final int normal = 0;
		final int inQuote = 1;
		final int inDoubleQuote = 2;
		int state = normal;
		final StringTokenizer tok = new StringTokenizer(toProcess, "\"\' ", true);
		final ArrayList<String> result = new ArrayList<String>();
		final StringBuilder current = new StringBuilder();
		boolean lastTokenHasBeenQuoted = false;

		while (tok.hasMoreTokens()) {
			String nextTok = tok.nextToken();
			switch (state) {
			case inQuote:
				if ("\'".equals(nextTok)) {
					lastTokenHasBeenQuoted = true;
					state = normal;
				} else {
					current.append(nextTok);
				}
				break;
			case inDoubleQuote:
				if ("\"".equals(nextTok)) {
					lastTokenHasBeenQuoted = true;
					state = normal;
				} else {
					current.append(nextTok);
				}
				break;
			default:
				if ("\'".equals(nextTok)) {
					state = inQuote;
				} else if ("\"".equals(nextTok)) {
					state = inDoubleQuote;
				} else if (" ".equals(nextTok)) {
					if (lastTokenHasBeenQuoted || current.length() != 0) {
						result.add(current.toString());
						current.setLength(0);
					}
				} else {
					current.append(nextTok);
				}
				lastTokenHasBeenQuoted = false;
				break;
			}
		}
		if (lastTokenHasBeenQuoted || current.length() != 0) {
			result.add(current.toString());
		}
		return result.toArray(new String[result.size()]);
	}

	@Override
	protected void onKick(String channel, String kickerNick, String kickerLogin, String kickerHostname,
			String recipientNick, String reason) {
		if (recipientNick.equals(getNick())) {
			disconnect();
			dispose();
		}
	}
	
	
}